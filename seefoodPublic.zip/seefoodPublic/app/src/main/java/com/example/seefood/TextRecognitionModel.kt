package com.example.seefood

data class TextRecognitionModel(val id: Int, val text: String?)